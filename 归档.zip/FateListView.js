/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { PureComponent } from 'react';
import {
    AppRegistry,
    StyleSheet,
    FlatList,
    View,
    Dimensions
} from 'react-native';

import getData from "./getData";
// import Cell from "./Cell";
// https://aliuat.memedai.cn/cms-portal-web/document/list @{@"pageNo":@(_pageNo),@"pageSize":@(10)}
import ArticleCell from './ArticleCell';
import DataSource from "./DataSource";

var cellHei = Dimensions.get('window').width * 360 / 750 + 80;

export default class FateListComponent extends PureComponent {
  state = {
    listData:DataSource,
  };

  _renderItem = ({item,index}) => (
    <ArticleCell data={item}/>
  );

  _keyExtractor = (item, index) => index;

  render() {
    return (
      <FlatList style={styles.container} initialNumToRender={1}
       data = {this.state.listData}
       renderItem={this._renderItem}
       onEndReached={()=>{
        this.setState({
          listData:this.state.listData.concat(DataSource)
        });
       }}
       keyExtractor={this._keyExtractor}
       getItemLayout= {(data,index) => (
          {length: cellHei, offset:(cellHei + 8) * index, index}
        )}
       ItemSeparatorComponent={() => (<View style={{height:8,backgroundColor:'#f5f5f5'}} />)} />
    );
  }
}

const styles = StyleSheet.create({
  container: { flex: 1 },
});
