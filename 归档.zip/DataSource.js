/**
 * Created by songzhanglong on 2017/6/23.
 */


var data = [
            {costTime:'260',displayTime:'1498115100000',displayType:'picture',documentNo:'3902898538427995',
                favoriteNumber:'74',isFavorite:'0',thumbnailUrl:'https://resource-uat.memedai.cn/4500_TJ966KB1-CGXL8FWBPO6353MYAET82-1J31P64J-0.png',
                videoUrl:'https://resource-uat.memedai.cn/4500_TJ966KB1-QFYLFY1RSMMQC0ZCJN1E3-QC4R284J-0.mp3',title:'春天里'},

            {costTime:'204',displayTime:'1497273540000',displayType:'picture',documentNo:'3061598967865570',
                favoriteNumber:'60',isFavorite:'0',thumbnailUrl:'https://resource-uat.memedai.cn/4500_TJ966KB1-CGOLNS51M12X71ZX7CVN1-XTMW1U3J-0.jpg',
                videoUrl:'https://resource-uat.memedai.cn/4500_TJ966KB1-RELLS3BRN6MQUAG8RS6L1-77HZRP3J-0.mp3',title:'【测试】视频'},

            {costTime:'0',displayTime:'1497513720000',displayType:'picture',documentNo:'1670965339678863',
            favoriteNumber:'55',isFavorite:'0',thumbnailUrl:'https://resource-uat.memedai.cn/4500_TJ966KB1-S58LB3ZZR20RJ1UO17XJ2-J8L0673J-0.jpg',
            videoUrl:'',title:'春天里'},

            {costTime:'0',displayTime:'1498133340000',displayType:'picture',documentNo:'2864642458813700',
                favoriteNumber:'11',isFavorite:'0',thumbnailUrl:'https://resource-uat.memedai.cn/4500_TJ966KB1-P7MLB7CZSKQ9SJST9KTN1-8EVNWQ3J-0.png',
                videoUrl:'',title:'测试下图片会不会等比缩放'},

            {costTime:'0',displayTime:'1498130280000',displayType:'picture',documentNo:'2086719804573298',
                favoriteNumber:'54',isFavorite:'0',thumbnailUrl:'https://resource-uat.memedai.cn/4500_TJ966KB1-8MYLT1CGNISW2UUO3TXT1-8F2VB84J-0.png',
                videoUrl:'',title:'你好'},

            {costTime:'174',displayTime:'1496288580000',displayType:'video',documentNo:'2076481102484049',
                favoriteNumber:'23',isFavorite:'0',thumbnailUrl:'https://resource-uat.memedai.cn/4500_TJ966KB1-MXCLNG52URTSC0DKTH4P2-EP4EVD3J-0.png',
                videoUrl:'https://resource-uat.memedai.cn/4500_TJ966KB1-6VCLP6R2RIGTG2GTVB0Z2-LM3YRD3J-0.mp4"',title:'知识贴：化妆的正确步骤'},

            {costTime:'0',displayTime:'1496227740000',displayType:'picture',documentNo:'2015777579138935',
                favoriteNumber:'33',isFavorite:'0',thumbnailUrl:'https://resource-uat.memedai.cn/4500_TJ966KB1-X7CL84ZZMNXX39MM1PSM1-INT9VC3J-0.jpg',
                videoUrl:'',title:'大量假货流入市场，你手里的娜丽丝防晒是正品吗？！'},

            {costTime:'304',displayTime:'1496225520000',displayType:'video',documentNo:'2006613665917419',
                favoriteNumber:'27',isFavorite:'0',thumbnailUrl:'https://resource-uat.memedai.cn/4500_TJ966KB1-86CLQTT0UFZ3WJ5N6C8V1-OK4XSC3J-0.jpg',
                videoUrl:'https://resource-uat.memedai.cn/4500_TJ966KB1-VUBLUGK8U2TMH07W24H93-VDNYCC3J-0.mp4',title:'微闪妆到底有多美？'},

            {costTime:'0',displayTime:'1497070020000',displayType:'picture',documentNo:'3902898538427995',
                favoriteNumber:'92',isFavorite:'0',thumbnailUrl:'https://resource-uat.memedai.cn/4500_TJ966KB1-14CL7H5KU58ZE2MY99FL3-6F8UPC3J-0.jpg',
                videoUrl:'',title:'谁说夏天只有土和黑？防晒在，美就在！主测商品'},

            {costTime:'0',displayTime:'1496211480000',displayType:'video',documentNo:'1998926419349239',
                favoriteNumber:'77',isFavorite:'0',thumbnailUrl:'https://resource-uat.memedai.cn/4500_TJ966KB1-0ZBL0489S8LJC1KR87UY2-XYNRIC3J-0.jpg',
                videoUrl:'https://resource-uat.memedai.cn/4500_TJ966KB1-YYBLSB5KN5G9G0ZPBWDR2-227OIC3J-0.mp4',title:'20多岁不做这６件事，你以后会哭的'}];

module.exports = data;