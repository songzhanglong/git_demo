/**
 * Created by songzhanglong on 2017/6/23.
 */


import React, { Component } from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image,
    Dimensions
} from 'react-native';

export default class ArticleCell extends Component{
    constructor(props){
        super(props);
    }

    render(){
        var {thumbnailUrl,title} = this.props.data;
        return (
            <View style={styles.container}>
                <Image style={styles.imgStyle} resizeMode={Image.resizeMode.cover} source={{uri:thumbnailUrl}}>

                </Image>
                <Text numberOfLines={1} style={styles.title}>
                    {title}
                </Text>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container:{
        height:Dimensions.get('window').width * 360 / 750 + 80,
        backgroundColor:'white',
        flexDirection:'column'
    },
    imgStyle:{
        flexDirection:'column',
        width:Dimensions.get('window').width,
        height:Dimensions.get('window').width * 360 / 750,
        justifyContent:'center',
        alignItems:'center',
        backgroundColor:'lightgray'
    },
    imgPlay:{
        width:20,
        height:20
    },
    textPlay:{
        color:'#1A2833',
        marginTop:5,
        fontSize:12
    },
    title:{
        color:'#1A2833',
        fontSize:14
    }
});