/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import {
  AppRegistry
} from 'react-native';

import FateListView from './FateListView';

AppRegistry.registerComponent('TaSay45', () => FateListView);
